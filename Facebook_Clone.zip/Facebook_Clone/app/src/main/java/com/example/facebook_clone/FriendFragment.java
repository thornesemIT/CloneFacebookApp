package com.example.facebook_clone;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class FriendFragment extends Fragment {
    ArrayList<Item> items;
    MyAdapter myAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_friend, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.friendRecyleview);
        items = new ArrayList<>();
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Thorne Sem", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("Kimsear Ly", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        items.add(new Item("ChhaiLeng Kheang", "Teacher of developer AD", R.drawable.thorne_progile));
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        myAdapter = new MyAdapter(getContext(), items, new MyAdapter.setOnItemClick() {
            @Override
            public void onItemClick(Item items) {
                Toast.makeText(getContext(), items.getName(), Toast.LENGTH_SHORT).show();
            }
        });
        recyclerView.setAdapter(myAdapter);
        return view;
    }
}