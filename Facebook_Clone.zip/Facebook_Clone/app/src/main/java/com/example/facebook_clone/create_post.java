package com.example.facebook_clone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class create_post extends AppCompatActivity {

    EditText editText;
    TextView textView;
    RelativeLayout relativeLayout;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);
        editText = findViewById(R.id.textfocus);
        relativeLayout = findViewById(R.id.bodyStory);
        imageView = findViewById(R.id.backicon);
        textView = findViewById(R.id.shownumber);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String inputText = editText.getText().toString();

                if (!inputText.isEmpty()) {
                    Long inputValue = Long.parseLong(inputText);

                    if (inputValue >= 0 && inputValue < 6000) {
                        textView.setText("0.2%");
                    } else if (inputValue >= 6000) {
                        textView.setText("0.1%");
                    } else {
                        textView.setText("No number!");
                    }
                } else {
                    textView.setText("0");
                }
            }
        });
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Backtohome();
            }
        });

        relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editText.requestFocus();
                showKeyboard(editText);
            }
        });
    }
    public void Backtohome()
    {
        onBackPressed();
    }
    public void showKeyboard(final EditText ettext){
        ettext.requestFocus();
        ettext.postDelayed(new Runnable(){
                               @Override public void run(){
                                   InputMethodManager keyboard=(InputMethodManager)getSystemService(getBaseContext().INPUT_METHOD_SERVICE);
                                   keyboard.showSoftInput(ettext,0);
                               }
                           }
                ,200);
    }
}