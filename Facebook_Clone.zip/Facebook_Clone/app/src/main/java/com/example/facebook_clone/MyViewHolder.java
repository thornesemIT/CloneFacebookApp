package com.example.facebook_clone;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder{
    ImageView imageView;
    TextView nameView, bioview;
    public MyViewHolder(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.image_friend);
        nameView = itemView.findViewById(R.id.Name_friend);
        bioview = itemView.findViewById(R.id.bio_friend);
    }
}
