package com.example.facebook_clone;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.viewHolder> {
    Context context;
    ArrayList<Item> items;
    setOnItemClick setOnItemClick;

    public MyAdapter(Context context, ArrayList<Item> items, MyAdapter.setOnItemClick setOnItemClick) {
        this.context = context;
        this.items = items;
        this.setOnItemClick = setOnItemClick;
    }

    @NonNull
    @Override
    public MyAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_view, null, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.viewHolder holder, int position) {
        Item listItem = items.get(position);
        holder.nameView.setText(listItem.getName());
        holder.bioView.setText(listItem.getEmail());
        holder.profileFriend.setImageResource(listItem.getImage());
        holder.itemView.setOnClickListener(View -> {
            setOnItemClick.onItemClick(items.get(position));
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder{
        TextView nameView, bioView;
        ImageView profileFriend;
        public viewHolder(@NonNull View itemView) {
            super(itemView);
            nameView = itemView.findViewById(R.id.Name_friend);
            bioView = itemView.findViewById(R.id.bio_friend);
            profileFriend = itemView.findViewById(R.id.image_friend);
        }
    }
    public interface setOnItemClick
    {
        void onItemClick(Item items);
    }
}
